/*!
 * license.js — 通用密钥授权启动器（v1）
 * 用法：<script src="license.js"></script>  License.start({...})
 * 依赖：WebCrypto（RSA-PSS-SHA256 或 Ed25519），单文件、零其它依赖。
 * 设计要点：
 *   1) 公钥内置在软件里、以此为准；清单里的 pubKey 必须与它一致，否则判为篡改。
 *   2) 签名内容 = "v1|密钥|用户名|到期日"，把密钥串本身也签进去（防止把别人的签名挪到自己的密钥上）。
 *   3) 离线兜底：上次成功联网验签的清单缓存在本地，7 天宽限；本地时间被调早则要求联网。
 */
(function (root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.License = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var PAYLOAD_V = 'v1';
  var DAY = 86400000;
  var ALGS = { 'RSA-PSS-SHA256': 1, 'Ed25519': 1 };

  var DEFAULTS = {
    appName: '软件',
    jsonUrl: '',        // 公开清单地址（Gist raw / 任意 http(s)）
    jsonUrls: [],       // 多个地址（主 + 镜像），按顺序试，任意一个成功即可
    urlTimeoutMs: 8000, // 单个地址的超时（被墙的连接会吊很久，别让它卡住激活）
    inlineJson: '',     // 内嵌清单（jsonUrl 不可用时先用它，仍需验签）
    pubKey: '',         // 内置公钥（base64 SPKI）
    alg: '',            // 留空＝按清单里的 alg；填了就强校验
    keyUrl: '',         // 可选：购买/续费页
    storageKey: 'license.v1',
    graceDays: 7,
    prompt: true,       // 是否用内置弹窗拦截
    onPass: null,
    onFail: null
  };

  /* ---------- 基础工具 ---------- */
  var mem = {};
  var LS = (function () {
    try { if (typeof localStorage !== 'undefined' && localStorage) return localStorage; } catch (e) {}
    return {
      getItem: function (k) { return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : null; },
      setItem: function (k, v) { mem[k] = String(v); },
      removeItem: function (k) { delete mem[k]; }
    };
  })();

  function load(sk) { try { return JSON.parse(LS.getItem(sk) || '{}') || {}; } catch (e) { return {}; } }
  function save(sk, o) { try { LS.setItem(sk, JSON.stringify(o)); } catch (e) {} }

  function b64e(buf) {
    var b = new Uint8Array(buf), s = '';
    for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]);
    return btoa(s);
  }
  function b64d(str) {
    var bin = atob(String(str).replace(/[\s\r\n]+/g, ''));
    var u = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
  function normB64(s) { return String(s || '').replace(/[\s\r\n]+/g, ''); }
  function normKey(s) { return String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, ''); }
  function fmtKey(s) {
    var n = normKey(s);
    return n.length > 4 ? n.replace(/(.{4})(?=.)/g, '$1-') : n;
  }
  function today(off) { return new Date(Date.now() + (off || 0) * DAY).toISOString().slice(0, 10); }
  function daysLeft(exp) {
    var d = (new Date(exp + 'T00:00:00Z').getTime() - new Date(today() + 'T00:00:00Z').getTime()) / DAY;
    return Math.round(d);
  }
  function payload(key, name, exp) { return [PAYLOAD_V, normKey(key), String(name || ''), String(exp || '')].join('|'); }

  function R(code, message, extra) {
    return Object.assign({ ok: code === 'OK', code: code, message: message || '' }, extra || {});
  }
  // file:// 页面取不到相对路径的清单，给一句可执行的提示
  function FILE_HINT() {
    return (typeof location !== 'undefined' && location.protocol === 'file:')
      ? '（双击打开的页面请把 jsonUrl 换成 https 的 Gist 地址）' : '';
  }

  /* ---------- 验签 ---------- */
  async function verifySig(alg, pubKeyB64, msg, sigB64) {
    if (!ALGS[alg]) throw new Error('不支持的算法：' + alg);
    var params = alg === 'Ed25519' ? { name: 'Ed25519' } : { name: 'RSA-PSS', hash: 'SHA-256' };
    var key = await crypto.subtle.importKey('spki', b64d(pubKeyB64), params, false, ['verify']);
    var vp = alg === 'Ed25519' ? { name: 'Ed25519' } : { name: 'RSA-PSS', saltLength: 32 };
    return await crypto.subtle.verify(vp, key, b64d(sigB64), new TextEncoder().encode(msg));
  }

  // 验一条密钥（doc = 公开清单对象）
  async function verifyEntry(key, doc, pubKey, wantAlg) {
    if (!doc || typeof doc !== 'object' || !doc.keys || typeof doc.keys !== 'object')
      return R('BAD_DOC', '授权清单格式不对');
    if (!pubKey) return R('NO_PUBKEY', '软件未内置公钥');
    var alg = doc.alg || wantAlg;
    if (!ALGS[alg]) return R('BAD_DOC', '清单算法字段无效：' + alg);
    if (wantAlg && doc.alg && doc.alg !== wantAlg) return R('ALG_MISMATCH', '清单算法与软件要求不一致');
    if (doc.pubKey && normB64(doc.pubKey) !== normB64(pubKey))
      return R('PUBKEY_MISMATCH', '授权清单的公钥与软件内置公钥不一致（清单可能被替换）');

    var k = normKey(key);
    if (!k) return R('NO_KEY', '请输入密钥');
    var rec = doc.keys[fmtKey(k)] || doc.keys[k];
    if (!rec) return R('NOT_FOUND', '密钥已被吊销或不存在（请联系发行方）');
    if (!rec.sig) return R('BAD_SIG', '密钥缺少签名');

    var ok = false;
    try { ok = await verifySig(alg, pubKey, payload(k, rec.name, rec.exp), rec.sig); }
    catch (e) { return R('BAD_SIG', '签名校验异常：' + (e && e.message ? e.message : e)); }
    if (!ok) return R('BAD_SIG', '密钥签名校验失败（清单被改过或密钥不对）');

    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(rec.exp || ''))) return R('BAD_EXP', '到期日格式不对');
    var left = daysLeft(rec.exp);
    if (left < 0) return R('EXPIRED', '密钥已到期（' + rec.exp + '，过期 ' + (-left) + ' 天）');
    return R('OK', '', { key: k, name: rec.name || '', exp: rec.exp, days: left, alg: alg });
  }

  /* ---------- 拉清单 ---------- */
  /* 清单地址列表：jsonUrls（数组，主→镜像）+ jsonUrl（单个，老配置）去重保序 */
  function urlList(c) {
    var a = [];
    if (c.jsonUrls && c.jsonUrls.length) a = a.concat(c.jsonUrls);
    if (c.jsonUrl) a.push(c.jsonUrl);
    return a.filter(function (u, i, s) { return u && s.indexOf(u) === i; });
  }

  function withTimeout(p, ms) {
    if (typeof AbortController === 'undefined') return p;
    var ac = new AbortController();
    var t = setTimeout(function () { ac.abort(); }, ms || 8000);
    return p(ac.signal).then(function (v) { clearTimeout(t); return v; },
                             function (e) { clearTimeout(t); throw e; });
  }

  /* 每个地址都拉一遍，取 updatedAt 最新的那份；全失败才抛错（让上层走缓存/宽限期）。
     Gist/Paste 这类源是 CDN，推送后各边缘节点缓存新旧不一（实测同一秒能给出两个版本），
     只认"第一个成功的"就可能拿到旧清单，吊销因此晚生效几分钟。 */
  async function fetchDoc(c) {
    var urls = urlList(c);
    if (!urls.length) throw new Error('未配置清单地址');
    var errs = [], docs = [];
    for (var i = 0; i < urls.length; i++) {
      var u = urls[i];
      var full = u + (u.indexOf('?') < 0 ? '?' : '&') + 't=' + Date.now() + '_' + i;
      try {
        var d = await withTimeout(function (sig) {
          return fetch(full, { cache: 'no-store', signal: sig }).then(function (res) {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return res.json();
          });
        }, c.urlTimeoutMs);
        if (d && typeof d === 'object') docs.push(d);
      } catch (e) {
        errs.push(u.replace(/^https?:\/\//, '').split('/')[0] + ':' + ((e && e.message) || e));
      }
    }
    if (!docs.length) throw new Error('清单地址都拉不到（' + errs.join('；') + '）');
    docs.sort(function (a, b) {
      return String(b.updatedAt || '').localeCompare(String(a.updatedAt || ''));
    });
    return docs[0];
  }

  /* ---------- 主流程 ---------- */
  var cfg = {};

  function withinGrace(st, c) {
    if (!st || !st.json) return false;
    if (st.lastOkAt && Date.now() < st.lastOkAt - DAY) return false;      // 系统时间被调早
    if (!st.lastOkAt || Date.now() - st.lastOkAt > c.graceDays * DAY) return false;
    return true;
  }
  function graceText(d) { return d >= 2 ? (d + ' 天') : Math.round(d * 24) + ' 小时'; }

  async function check(opts) {
    var c = Object.assign({}, DEFAULTS, cfg, opts || {});
    if (!c.pubKey) return R('NO_PUBKEY', '软件未内置公钥');
    var st = load(c.storageKey);
    if (!st.key) return R('NO_KEY', '请输入密钥');

    var doc = null, online = false, why = '';
    try { doc = await fetchDoc(c); online = true; }
    catch (e) { why = (e && e.message) || String(e); }
    if (!online && !urlList(c).length && c.inlineJson) {
      // 只有「离线单机形态」（根本没配在线清单地址）才允许用内嵌清单。
      // 配了 jsonUrl 就表示以在线清单为准：拉不到必须走「缓存 + 宽限期」，否则内嵌清单会永久
      // 放行已吊销的密钥（2026-09-29 修的严重 BUG：吊销后客户端照用）。
      try { doc = JSON.parse(c.inlineJson); online = true; why = ''; } catch (e) {}
    }

    if (!online) {  // 断网：走本地缓存 + 宽限期
      if (!withinGrace(st, c)) {
        if (st.json && st.lastOkAt && Date.now() < st.lastOkAt - DAY)
          return R('CLOCK_TAMPER', '检测到系统时间被调早，请联网重新验证');
        if (st.json && st.lastOkAt && Date.now() - st.lastOkAt > c.graceDays * DAY)
          return R('GRACE_EXPIRED', '离线已超过 ' + graceText(c.graceDays) + '，请联网重新验证');
        return R('NET_NO_CACHE', '连不上授权服务器，且本机没有可用缓存' + FILE_HINT());
      }
      try { doc = JSON.parse(st.json); } catch (e) { return R('NET_NO_CACHE', '连不上授权服务器，且本机缓存已损坏' + FILE_HINT()); }
    }

    var r = await verifyEntry(st.key, doc, c.pubKey, c.alg);

    // 清单能下载但结构坏了（例如 Gist 半截）→ 退回缓存，避免误锁
    if (!r.ok && r.code === 'BAD_DOC' && withinGrace(st, c)) {
      try { r = await verifyEntry(st.key, JSON.parse(st.json), c.pubKey, c.alg); online = false; why = '清单损坏，已用缓存'; } catch (e) {}
    }
    if (r.ok) {
      if (online) save(c.storageKey, { key: st.key, name: r.name, exp: r.exp, lastOkAt: Date.now(), json: JSON.stringify(doc) });
      r.source = online ? 'online' : 'cache';
      r.note = why;
      return r;
    }
    r.source = online ? 'online' : 'cache';
    if (why && !r.message) r.message = why;
    return r;
  }

  function setKey(k) {
    var st = load(cfg.storageKey || DEFAULTS.storageKey);
    st.key = normKey(k);
    save(cfg.storageKey || DEFAULTS.storageKey, st);
    return st.key;
  }
  function clear() { LS.removeItem(cfg.storageKey || DEFAULTS.storageKey); }
  function state() { return load(cfg.storageKey || DEFAULTS.storageKey); }

  /* ---------- 内置拦截弹窗 ---------- */
  var CSS = '.lic-scr{position:fixed;inset:0;background:rgba(24,28,34,.42);z-index:2147483000;display:flex;align-items:center;justify-content:center;font:14px/1.7 system-ui,"Microsoft YaHei",sans-serif;color:#222}' +
    '.lic-card{width:400px;background:#fff;border:1px solid #d8dde3;border-radius:6px;padding:20px}' +
    '.lic-card h3{margin:0 0 4px;font-size:16px;color:#1f4e79}' +
    '.lic-sub{color:#777;font-size:12px;margin-bottom:14px}' +
    '.lic-in{width:100%;height:32px;box-sizing:border-box;border:1px solid #ccd3da;border-radius:4px;padding:0 10px;font:14px/32px ui-monospace,Consolas,monospace;letter-spacing:1px;text-transform:uppercase}' +
    '.lic-in:focus{outline:none;border-color:#1f4e79}' +
    '.lic-btn{margin-top:10px;width:100%;height:32px;border:1px solid #1f4e79;background:#1f4e79;color:#fff;border-radius:4px;cursor:pointer;font-size:14px}' +
    '.lic-btn:disabled{opacity:.6;cursor:default}' +
    '.lic-link{background:none;border:0;color:#1f4e79;font-size:12px;cursor:pointer;padding:0}' +
    '.lic-msg{margin-top:10px;font-size:13px;color:#b04a2f;min-height:18px}' +
    '.lic-msg.ok{color:#2f7d4f}' +
    '.lic-foot{margin-top:12px;display:flex;justify-content:space-between;align-items:center;color:#999;font-size:12px}';

  function styleOnce() {
    if (typeof document === 'undefined' || document.getElementById('lic-style')) return;
    var s = document.createElement('style'); s.id = 'lic-style'; s.textContent = CSS;
    document.head.appendChild(s);
  }

  function mountGate(c, first) {
    styleOnce();
    var scr = document.createElement('div'); scr.className = 'lic-scr';
    var st = state();
    scr.innerHTML =
      '<div class="lic-card">' +
      '<h3>' + esc(c.appName) + ' · 授权验证</h3>' +
      '<div class="lic-sub">请输入你的授权密钥</div>' +
      '<input class="lic-in" placeholder="XXXX-XXXX-XXXX" value="' + esc(fmtKey(st.key || '')) + '">' +
      '<button class="lic-btn">验证并进入</button>' +
      '<div class="lic-msg"' + (first && first.message ? '' : '') + '>' + esc(first && first.message && first.code !== 'NO_KEY' ? first.message : '') + '</div>' +
      '<div class="lic-foot"><span>' + (c.keyUrl ? '<button class="lic-link" data-go>购买 / 续费</button>' : '<span>密钥由发行方提供</span>') + '</span><span>可离线使用 ' + graceText(c.graceDays) + '</span></div>' +
      '</div>';
    document.body.appendChild(scr);

    var inp = scr.querySelector('.lic-in'), btn = scr.querySelector('.lic-btn'), msg = scr.querySelector('.lic-msg');
    inp.focus(); inp.select();
    if (cfg.onFail) cfg.onFail(first);

    async function submit() {
      var v = inp.value;
      if (!normKey(v)) { msg.textContent = '请输入密钥'; return; }
      btn.disabled = true; msg.className = 'lic-msg'; msg.textContent = '验证中…';
      setKey(v);
      var r = await check(c);
      if (r.ok) {
        msg.className = 'lic-msg ok';
        msg.textContent = '通过：' + r.name + ' · 有效期至 ' + r.exp;
        setTimeout(function () { if (scr.parentNode) scr.parentNode.removeChild(scr); }, 500);
        if (c.onPass) c.onPass(r);
      } else {
        btn.disabled = false;
        msg.textContent = (r.code === 'NOT_FOUND' ? '密钥已被吊销或不存在'
          : r.code === 'NO_PUBKEY' ? '软件未配置公钥'
          : r.code === 'PUBKEY_MISMATCH' ? '授权清单公钥异常，请联系发行方'
          : r.message || '密钥无效');
      }
    }
    btn.onclick = submit;
    inp.onkeydown = function (e) { if (e.key === 'Enter') submit(); };
    var go = scr.querySelector('[data-go]');
    if (go) go.onclick = function () { window.open(c.keyUrl, '_blank'); };
    return { el: scr, retry: submit };
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (m) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[m]; }); }

  /* ---------- 对外接口 ---------- */
  async function start(opts) {
    var c = Object.assign({}, DEFAULTS, cfg, opts || {});
    cfg = c;
    var r = await check(c);
    if (r.ok) { if (c.onPass) c.onPass(r); return r; }
    if (c.prompt) return mountGate(c, r);   // 未付费/密钥错 → 弹窗重试
    if (c.onFail) c.onFail(r);
    return r;
  }

  async function fingerprint(pubKeyB64) {
    var buf = await crypto.subtle.digest('SHA-256', b64d(pubKeyB64));
    return Array.prototype.map.call(new Uint8Array(buf).slice(0, 8), function (b) {
      return ('0' + b.toString(16)).slice(-2);
    }).join('');
  }

  return {
    version: '1.0',
    DEFAULTS: DEFAULTS,
    start: start,
    check: check,
    verifyEntry: verifyEntry,
    verifySig: verifySig,
    setKey: setKey,
    clear: clear,
    state: state,
    fingerprint: fingerprint,
    fmtKey: fmtKey,
    normKey: normKey,
    payload: payload,
    today: today,
    daysLeft: daysLeft,
    _mountGate: mountGate
  };
});
