/*!
 * lic-guard.js —— 授权守卫（第 2、3 层）
 *
 * 第 1 层在 license.js + 闸门脚本里（没密钥时界面整块隐藏）。
 * 这一层做两件事，专门提高「直接改文件绕过」的代价：
 *
 *   第 2 层｜动作级拦截：未授权时，凡是"花算力 / 出成果"的动作（提取、识别、出题、导出、AI 整理…）
 *            一律不执行，并提示去输密钥。⇒ 光把闸门那段删掉没用，还得逐个把这些动作也改一遍。
 *
 *   第 3 层｜发行方封条：发行方签发密钥时，会用私钥对「程序文件哈希」签名，写进清单的 seal 字段。
 *            页面加载后重新算一遍哈希并用内置公钥验签；对不上就挂一条顶部横幅。
 *            ⚠️ 只提示、不锁功能 —— 免得发行方自己更新了程序文件而封条没来得及刷新时误伤客户。
 *
 * 说明（写在明处，别自欺）：纯前端做不到"真防改"，能做的只是把门槛抬高、把改动变得可见。
 * 真要强控制，得把关键能力放到服务端。
 */
(function () {
  'use strict';

  function licOK() { return !!(window.__LIC && window.__LIC.ok); }
  window.__LIC_OK = licOK;

  /* ---------------- 第 2 层：动作级拦截 ---------------- */
  /* 应用的动作表 ACTIONS2 是私有对象（在 IIFE 里，window 上取不到），
     所以主拦法是在**点击到达应用之前**把它掐掉（捕获阶段），另加一层"若 ACTIONS2 恰好在全局就包一层"。 */
  var GUARD = [
    // 提取 / 识别（最费算力和时间的一批）
    'exStart', 'exRunHere', 'exOnlineSeg', 'exReocrFirst', 'ocrRun', 'ocrExtract', 'ocrPages',
    'v50Run', 'v51Run', 'v51Pair', 'reparseOriginal', 'buildIndex', 'recountPages',
    // 出题 / 组卷 / 导出（真正的成果）
    'runGenBlocks', 'runGenBlocks2', 'exportPDF', 'exportPaperPDF', 'exportWord', 'exportFull',
    'exportJSON', 'aiOrganize', 'fillAnalysis', 'ansFill', 'autoBind', 'packBodies', 'figsToPrep',
    // 资料入库（等于把外部东西搬进来用）
    'pickFolder', 'pickFullBackup', 'continueImport'
  ];
  var warned = 0;
  function deny() {
    if (warned) return;
    warned = 1;
    setTimeout(function () { warned = 0; }, 1500);
    try { alert('未授权：请先在授权窗口输入发行方给你的密钥'); } catch (e) {}
  }
  function isGuarded(act) { return GUARD.indexOf(act) >= 0; }

  document.addEventListener('click', function (e) {
    var el = e.target && e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el) return;
    if (!licOK() && isGuarded(el.getAttribute('data-act'))) {
      e.preventDefault();
      e.stopImmediatePropagation();     // 让应用自己的处理器收不到这次点击
      deny();
    }
  }, true);

  /* 拖进来的文件、选的备份文件也算"把东西搬进来"，未授权一并拦住 */
  ['drop', 'change'].forEach(function (ev) {
    document.addEventListener(ev, function (e) {
      if (licOK()) return;
      var t = e.target || {};
      var isFile = (t.tagName === 'INPUT' && String(t.type).toLowerCase() === 'file') || ev === 'drop';
      if (isFile) { e.preventDefault(); e.stopImmediatePropagation(); deny(); }
    }, true);
  });

  /* 万一某个版本把动作表挂到了全局，顺手也包一层 */
  function wrap(o, n) {
    var f = o[n];
    if (typeof f !== 'function' || f.__licGuard) return;
    var g = function () {
      if (!licOK()) { deny(); return; }
      return f.apply(this, arguments);
    };
    g.__licGuard = 1;
    o[n] = g;
  }
  function sweep() {
    var o = window.ACTIONS2;
    if (!o) return;
    for (var i = 0; i < GUARD.length; i++) wrap(o, GUARD[i]);
  }
  setInterval(sweep, 1200);
  sweep();

  /* ---------------- 第 3 层：发行方封条 ---------------- */
  function hex(buf) {
    return [].map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }
  function sha256(buf) { return crypto.subtle.digest('SHA-256', buf).then(hex); }
  function b64d(s) {
    var bin = atob(String(s).replace(/[\s\r\n]+/g, '')), u = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
  function banner(msg) {
    if (document.getElementById('lic-tamper')) return;
    var d = document.createElement('div');
    d.id = 'lic-tamper';
    d.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:2147483002;background:#fdecea;color:#b42318;'
      + 'font:13px/1.9 system-ui,"Microsoft YaHei",sans-serif;padding:2px 10px;text-align:center';
    d.textContent = '⚠ 检测到程序文件与发行方封条不一致（' + msg + '）——授权校验可能已被改动，请使用发行方提供的完整包';
    document.body.appendChild(d);
  }
  function sealText(files) {
    return 'seal|' + Object.keys(files).sort().map(function (k) { return k + '=' + files[k]; }).join('|');
  }
  function verifySeal(cfg, alg, files, sigB64) {
    var params = alg === 'Ed25519' ? { name: 'Ed25519' } : { name: 'RSA-PSS', hash: 'SHA-256' };
    var vp = alg === 'Ed25519' ? { name: 'Ed25519' } : { name: 'RSA-PSS', saltLength: 32 };
    return crypto.subtle.importKey('spki', b64d(cfg.pubKey), params, false, ['verify']).then(function (key) {
      return crypto.subtle.verify(vp, key, b64d(sigB64), new TextEncoder().encode(sealText(files)));
    });
  }
  function checkSeal() {
    var cfg = window.LIC || {};
    if (!cfg.pubKey || !crypto || !crypto.subtle) return;
    var doc = {};
    try { doc = JSON.parse(cfg.inlineJson || '{}'); } catch (e) {}
    var s = doc.seal;
    if (!s || !s.sig || !s.files) return;                 // 老包没有封条 → 跳过（不误报）
    var names = Object.keys(s.files);
    // ① 先验封条本身是不是发行方签的（防止"改了文件顺手把哈希也改掉"）
    verifySeal(cfg, doc.alg || 'RSA-PSS-SHA256', s.files, s.sig).then(function (sigOK) {
      if (!sigOK) { banner('封条签名对不上'); return; }
      // ② 再比对本地文件哈希（发现有文件被改过）
      //    注意：单文件版（在线版/平板版/APK）里这些文件被内联了，fetch 会 404 或取不到——
      //    那种情况一律按"取不到 → 不判它"处理，否则客户会看到假的"文件已改动"红条。
      Promise.all(names.map(function (n) {
        return fetch(n, { cache: 'no-store' }).then(function (r) {
          if (!r || !r.ok) return s.files[n];                       // 404/403 等：不判它
          return r.arrayBuffer().then(sha256);
        }).catch(function () { return s.files[n]; });               // 取不到/跨域：不判它
      })).then(function (got) {
        var bad = [];
        names.forEach(function (n, i) { if (got[i] !== s.files[n]) bad.push(n); });
        if (bad.length) banner(bad.join('、') + ' 已改动');
      }).catch(function () {});
    }).catch(function () {});
  }
  setTimeout(checkSeal, 1500);

  /* 便于排查：暴露一下自己的状态 */
  window.__LIC_GUARD = { ok: licOK, guard: GUARD, checkSeal: checkSeal };
})();
